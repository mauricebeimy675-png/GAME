---
name: montage-video
description: >-
  Monte une vidéo face caméra en local : coupe les blancs, les « euh » et les reprises, sous-titres, son et format vertical. Se déclenche sur « monte ma vidéo », « dérushe », « coupe les blancs ».
---

# Monter une vidéo face caméra

Skill publié par Loris Gautier, lorisgautier.fr. Version de départ, pour une personne qui parle face
caméra. Tout tourne sur l'ordinateur de l'utilisateur, rien n'est envoyé en ligne.

## Le principe, à respecter

Tu ne regardes pas la vidéo et tu n'écoutes pas le son. Les scripts découpent la parole en « îlots »,
les passages entre deux blancs, et transcrivent chaque îlot. Tu décides quels îlots garder en lisant
le texte. Les coupes tombent donc toujours dans un blanc, jamais au milieu d'un mot.

Tu ne calcules jamais une durée, un timecode ni un pourcentage de tête : ce sont les scripts qui
mesurent, et tu recopies leurs chiffres.

Ce skill marche dans Claude Code ou dans l'onglet Code de Claude Desktop, en environnement local. Il
ne marche pas dans le chat de claude.ai ni dans une session cloud : si l'utilisateur y est, dis-le.

## 0. Vérifier les outils

```
python3 "${CLAUDE_SKILL_DIR}/scripts/verifier.py"
```

Si quelque chose manque, montre à l'utilisateur la commande d'installation affichée et demande son
accord avant de l'exécuter : installer un logiciel modifie sa machine. Sur Windows, la commande est
`python` au lieu de `python3`. Le modèle de transcription se télécharge avec
`verifier.py --telecharger-modele` (environ 550 Mo, une seule fois).

## 1. Préparer

```
python3 "${CLAUDE_SKILL_DIR}/scripts/preparer.py" "CHEMIN/DE/LA/VIDEO.mp4"
```

Le script crée un dossier `montage-NOM` à côté de la vidéo, avec `ilots.txt`. Une vidéo à la fois :
si l'utilisateur a plusieurs rushs d'une même prise de parole, propose de les assembler d'abord avec
ffmpeg (concat), puis prépare le fichier assemblé. Sur une longue vidéo, la commande peut dépasser
deux minutes : laisse-la finir en arrière-plan.

Si le résultat paraît faux (un seul îlot énorme, ou des dizaines d'îlots d'une fraction de seconde),
la pièce est bruyante ou la voix faible : relance avec `--seuil -30` ou `--seuil -40`, et
`--silence 0.5` pour ignorer les respirations.

## 2. Proposer, puis relire le plan

```
python3 "${CLAUDE_SKILL_DIR}/scripts/proposer.py" "DOSSIER"
```

Le script propose de couper les îlots vides, les hésitations (« euh », « bon ») et les reprises
évidentes, et écrit `plan.json`. Ce n'est qu'une première passe. Lis ensuite `ilots.txt` en entier
et corrige le plan :

- **Les reprises oubliées.** Une phrase commencée puis recommencée, une idée dite deux fois de suite :
  garde la dernière prise complète, sauf si l'utilisateur a dit le contraire.
- **Les mots de bord.** Un mot peut être rangé dans l'îlot voisin de celui où il est prononcé. Juge
  sur le sens de la phrase, pas mot à mot.
- **Les îlots « à vérifier ».** Un passage sans texte peut être de la vraie parole que la
  transcription a perdue. Ne le coupe jamais sans demander : donne son horaire et fais-le écouter.
- **L'orthographe des noms.** Corrige dans `ilots.json` les noms propres mal transcrits (marques,
  prénoms, outils), dans le champ `texte` seulement : c'est ce texte qui sert aux sous-titres. Ne
  touche jamais aux horaires.

Mets à jour la liste `garder` de `plan.json`, puis montre à l'utilisateur un tableau court : îlot,
horaire, texte, décision et raison. **Attends sa validation avant tout rendu.**

## 3. Rendre

Demande quelles versions il veut : horizontale seule, avec sous-titres incrustés, verticale 9:16
(recadrée au centre) pour les Reels et les Shorts.

```
python3 "${CLAUDE_SKILL_DIR}/scripts/rendre.py" "DOSSIER" --sous-titres --vertical
```

Si ffmpeg n'a pas de quoi incruster les sous-titres, le script le signale et les laisse dans
`montage.srt`, que la plupart des plateformes acceptent en fichier à part. Sur Mac, la solution est
`brew install ffmpeg-full`.

## 4. Livrer

Recopie la ligne de bilan du script (durée source, durée du montage, temps retiré, raccords) et la
liste des fichiers. Donne les horaires de `raccords.txt` : ce sont les endroits à écouter en premier.
Propose les retouches possibles, puis relance le rendu :

- un raccord trop sec : `--marge-apres 0.25` ;
- un souffle en trop : `--marge-avant 0.04` ;
- un passage coupé à tort : remets son numéro dans `garder`.

## Ce que tu ne fais pas

Tu ne coupes pas à l'intérieur d'un îlot : si l'utilisateur veut retirer un mot au milieu d'une
phrase, dis que ce skill coupe entre les phrases, pas dans une phrase. Tu n'ajoutes ni musique, ni
plans de coupe, ni effets. Tu ne supprimes jamais les fichiers d'origine. Tu n'envoies aucun fichier
en ligne.
