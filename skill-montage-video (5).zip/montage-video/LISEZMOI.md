# Le skill Montage vidéo pour Claude

Ce que vous avez entre les mains : la méthode que Claude suit pour monter une vidéo face caméra sur votre ordinateur. Il repère les blancs, retire les « euh » et les reprises en gardant la dernière prise, vous montre la liste des coupes, puis sort la vidéo montée avec le son réglé, les sous-titres et une version verticale pour les Reels et les Shorts.

**Tout reste sur votre ordinateur.** La transcription tourne en local, aucune vidéo n'est envoyée en ligne, et rien n'est coupé avant que vous ayez validé la liste des coupes.

## Ce qu'il faut avant

- Un abonnement Claude Pro ou supérieur, et l'application Claude Desktop, onglet **Code**, en environnement **Local**. Ce skill ne marche pas dans le chat de claude.ai : il a besoin de votre ordinateur.
- Un Mac ou un PC Windows, avec Python 3. Sur Mac, il s'installe tout seul la première fois qu'on tape `python3` ; sur Windows : `winget install Python.Python.3.12`.
- ffmpeg et Whisper, deux logiciels gratuits. Claude vous propose de les installer à la première utilisation, voici les commandes pour les avoir sous la main.

Sur Mac :

```
brew install ffmpeg-full whisper-cpp
echo 'export PATH="/opt/homebrew/opt/ffmpeg-full/bin:$PATH"' >> ~/.zshrc
```

Prenez bien `ffmpeg-full` : le `ffmpeg` standard de Homebrew ne sait pas incruster de sous-titres.

Sur Windows :

```
winget install Gyan.FFmpeg
```

Puis téléchargez `whisper-bin-x64.zip` sur la page des versions de whisper.cpp (github.com/ggml-org/whisper.cpp/releases), dézippez-le et ajoutez le dossier au PATH. J'ai testé ce skill sur Mac ; sur Windows, les outils sont les mêmes mais je ne l'ai pas encore fait tourner moi-même.

## Installation, deux minutes

1. Gardez le fichier `skill-montage-video.zip`.
2. Dans Claude Desktop, onglet Code, ouvrez un dossier puis écrivez : **installe le skill contenu dans ~/Downloads/skill-montage-video.zip dans ~/.claude/skills**. Claude le dézippe au bon endroit. Vous pouvez aussi le faire à la main : dézippez-le, le dossier `montage-video` doit finir dans `~/.claude/skills/`.
3. Ouvrez une nouvelle session et écrivez : **monte ma vidéo ~/Movies/ma-video.mp4**.

La première fois, Claude vérifie les outils et télécharge le modèle de transcription (environ 550 Mo, une seule fois).

## Comment l'utiliser

- Filmez-vous comme d'habitude, et quand vous ratez une phrase, marquez une petite pause et recommencez-la en entier : le skill garde la dernière prise.
- Relisez le tableau des coupes que Claude vous montre. C'est le moment de dire « garde le passage 12 » ou « coupe aussi le 7 ».
- Écoutez d'abord les raccords listés dans `raccords.txt`, ce sont les endroits où une coupe peut s'entendre.
- Sur mon Mac, une vidéo de démonstration de 49 secondes a été préparée en 3 secondes et rendue en 10 secondes, trois versions comprises.

## Ce que ce skill ne fait pas

Il coupe entre les phrases, pas au milieu d'une phrase. Il n'ajoute ni musique, ni plans de coupe, ni animations, et le format vertical est recadré au centre, sans suivi du visage. Si vous voulez que Claude monte vos vidéos à partir de vos propres modèles, publie sur vos réseaux ou range vos rushs, écrivez-moi sur lorisgautier.fr, l'audit est offert.

Loris Gautier · lorisgautier.fr
