"""Étape 2 : propose un plan de coupe à partir des îlots transcrits.

Coupe proposée pour : les îlots vides ou faits seulement d'hésitations (« euh », « bon »...),
et les reprises (un faux départ ou une phrase redite juste après : on garde la dernière prise).
Le plan est une proposition : il se relit et se corrige avant le rendu.

Usage : python3 proposer.py DOSSIER
Sortie : DOSSIER/plan.json (ids gardés) et un tableau à relire
"""
import difflib
import json
import os
import re
import sys
import unicodedata

HESITATIONS = {"euh", "heu", "hum", "hmm", "mmh", "bah", "ben", "bon", "alors", "donc", "voila", "enfin", "hein", "ok", "okay"}


def normaliser(texte):
    texte = re.sub(r"[\[\(][^\]\)]*[\]\)]", " ", texte)  # [Musique], (rires), [BLANK_AUDIO]
    texte = unicodedata.normalize("NFD", texte.lower())
    texte = "".join(c for c in texte if unicodedata.category(c) != "Mn")
    return re.findall(r"[a-z0-9']+", texte)


def sans_hesitations(mots):
    return [m for m in mots if m not in HESITATIONS]


def main():
    if len(sys.argv) < 2:
        sys.exit("Usage : python3 proposer.py DOSSIER")
    dossier = sys.argv[1]
    with open(os.path.join(dossier, "ilots.json"), encoding="utf-8") as f:
        donnees = json.load(f)
    ilots = donnees["ilots"]
    mots = {il["id"]: sans_hesitations(normaliser(il["texte"])) for il in ilots}

    couper, verifier = {}, {}
    for il in ilots:
        m = mots[il["id"]]
        brut = normaliser(il["texte"])
        if not brut:
            # un passage long sans texte peut être de la vraie parole que Whisper a perdue : on ne coupe pas d'office
            if il["duree"] < 0.8:
                couper[il["id"]] = "bruit ou souffle, sans texte"
            else:
                verifier[il["id"]] = "aucun texte transcrit sur un passage long : à écouter"
            continue
        if not m:
            couper[il["id"]] = "hésitation seule"
            continue
        if il["duree"] < 0.5 and len(m) <= 2:
            couper[il["id"]] = "très court, hésitation probable"
            continue
        for suivant in ilots:
            if suivant["id"] <= il["id"] or suivant["id"] > il["id"] + 4 or suivant["debut"] - il["fin"] > 60:
                continue
            s = mots[suivant["id"]]
            if not s:
                continue
            faux_depart = len(m) >= 3 and len(m) < len(s) and s[: len(m)] == m
            ratio = difflib.SequenceMatcher(None, m, s).ratio()
            redite = len(m) >= 3 and ratio >= 0.6 and len(s) >= 0.6 * len(m)
            if faux_depart or redite:
                couper[il["id"]] = f"reprise, remplacée par #{suivant['id']:03d}"
                break

    garder = [il["id"] for il in ilots if il["id"] not in couper]
    plan = {"garder": garder,
            "coupes_proposees": [{"id": k, "raison": v} for k, v in sorted(couper.items())],
            "a_verifier": [{"id": k, "raison": v} for k, v in sorted(verifier.items())]}
    with open(os.path.join(dossier, "plan.json"), "w", encoding="utf-8") as f:
        json.dump(plan, f, ensure_ascii=False, indent=1)

    total_coupe = sum(il["duree"] for il in ilots if il["id"] in couper)
    print(f"{len(ilots)} îlots | {len(couper)} coupes proposées | {len(verifier)} à vérifier | parole retirée : {total_coupe:.1f} s")
    print()
    print("| Îlot | Temps | Texte | Décision |")
    print("| --- | --- | --- | --- |")
    for il in ilots:
        if il["id"] in couper:
            decision = "couper : " + couper[il["id"]]
        elif il["id"] in verifier:
            decision = "garder, à vérifier : " + verifier[il["id"]]
        else:
            decision = "garder"
        texte = il["texte"] if len(il["texte"]) < 90 else il["texte"][:87] + "..."
        print(f"| #{il['id']:03d} | {il['debut']:.1f} s | {texte or '(rien)'} | {decision} |")
    print()
    print("Plan écrit dans", os.path.join(dossier, "plan.json"), ": à valider avant le rendu.")


if __name__ == "__main__":
    main()
