"""Fonctions communes du skill montage-video : trouver ffmpeg, ffprobe, whisper-cli et le modèle."""
import glob
import json
import os
import platform
import shutil
import subprocess
import sys

MODELE_URL = "https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-large-v3-turbo-q5_0.bin"
MODELE_NOM = "ggml-large-v3-turbo-q5_0.bin"


def _premier_existant(chemins):
    for chemin in chemins:
        if chemin and os.path.isfile(chemin):
            return chemin
    return None


def trouver_ffmpeg(nom="ffmpeg"):
    """Préfère un ffmpeg complet (avec libass) : variable d'environnement, ffmpeg-full de Homebrew, puis le PATH."""
    variable = os.environ.get("FFMPEG" if nom == "ffmpeg" else "FFPROBE")
    candidats = [
        variable,
        f"/opt/homebrew/opt/ffmpeg-full/bin/{nom}",
        f"/usr/local/opt/ffmpeg-full/bin/{nom}",
    ]
    trouve = _premier_existant(candidats)
    return trouve or shutil.which(nom) or shutil.which(nom + ".exe")


def trouver_whisper():
    variable = os.environ.get("WHISPER_CLI")
    if variable and os.path.isfile(variable):
        return variable
    for nom in ("whisper-cli", "whisper-cli.exe", "whisper-cpp", "main"):
        chemin = shutil.which(nom)
        if chemin:
            return chemin
    return None


def dossier_modeles():
    return os.path.join(os.path.expanduser("~"), ".cache", "whisper")


def trouver_modele():
    variable = os.environ.get("WHISPER_MODEL")
    if variable and os.path.isfile(variable):
        return variable
    ici = os.path.dirname(os.path.abspath(__file__))
    candidats = []
    for dossier in (dossier_modeles(), os.path.join(ici, "..", "modeles"), "/opt/homebrew/share/whisper-cpp"):
        candidats += sorted(glob.glob(os.path.join(dossier, "ggml-*.bin")))
    # le plus gros modèle trouvé transcrit le mieux, on écarte les modèles de test
    candidats = [c for c in candidats if "for-tests" not in c]
    if not candidats:
        return None
    return max(candidats, key=os.path.getsize)


def lancer(commande, cwd=None):
    """Lance une commande et renvoie sa sortie ; s'arrête avec un message clair en cas d'échec."""
    resultat = subprocess.run(commande, cwd=cwd, capture_output=True, text=True, encoding="utf-8", errors="replace")
    if resultat.returncode != 0:
        sys.stderr.write("La commande a échoué : " + " ".join(commande[:3]) + " ...\n")
        sys.stderr.write(resultat.stderr[-2500:] + "\n")
        sys.exit(resultat.returncode)
    return resultat


def duree(fichier, ffprobe=None):
    ffprobe = ffprobe or trouver_ffmpeg("ffprobe")
    sortie = lancer([ffprobe, "-v", "error", "-show_entries", "format=duration", "-of", "json", fichier]).stdout
    return float(json.loads(sortie)["format"]["duration"])


def a_le_filtre(ffmpeg, filtre):
    sortie = subprocess.run([ffmpeg, "-hide_banner", "-filters"], capture_output=True, text=True, errors="replace").stdout
    return any(ligne.split()[1:2] == [filtre] for ligne in sortie.splitlines() if len(ligne.split()) > 1)


def encodeur_video(ffmpeg):
    """Encodeur matériel sur Mac (nettement plus rapide), sinon libx264."""
    sortie = subprocess.run([ffmpeg, "-hide_banner", "-encoders"], capture_output=True, text=True, errors="replace").stdout
    if platform.system() == "Darwin" and "h264_videotoolbox" in sortie:
        return ["-c:v", "h264_videotoolbox", "-q:v", "65"]
    return ["-c:v", "libx264", "-preset", "medium", "-crf", "20"]


def version_majeure(ffmpeg):
    sortie = subprocess.run([ffmpeg, "-version"], capture_output=True, text=True, errors="replace").stdout
    try:
        version = sortie.split()[2]
        return int(version.split(".")[0].lstrip("n"))
    except (IndexError, ValueError):
        return 0


def dossier_de_travail(video, dossier=None):
    if dossier:
        chemin = dossier
    else:
        base = os.path.splitext(os.path.basename(video))[0]
        chemin = os.path.join(os.path.dirname(os.path.abspath(video)), "montage-" + base)
    os.makedirs(chemin, exist_ok=True)
    return chemin


def secondes(t):
    """12.345 -> 00:00:12.345"""
    h = int(t // 3600)
    m = int((t % 3600) // 60)
    s = t - h * 3600 - m * 60
    return f"{h:02d}:{m:02d}:{s:06.3f}"
