"""Vérifie que tout est prêt pour monter : ffmpeg (avec les sous-titres), ffprobe, whisper-cli et un modèle.

Usage : python3 verifier.py            -> état des outils
        python3 verifier.py --telecharger-modele   -> télécharge le modèle Whisper (environ 550 Mo)
"""
import os
import sys
import urllib.request

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import outils  # noqa: E402


def telecharger_modele():
    os.makedirs(outils.dossier_modeles(), exist_ok=True)
    cible = os.path.join(outils.dossier_modeles(), outils.MODELE_NOM)
    if os.path.isfile(cible):
        print("Modèle déjà présent :", cible)
        return
    print("Téléchargement du modèle Whisper large-v3-turbo (environ 550 Mo) vers", cible)
    urllib.request.urlretrieve(outils.MODELE_URL, cible + ".part")
    os.replace(cible + ".part", cible)
    print("Modèle téléchargé.")


def main():
    if "--telecharger-modele" in sys.argv:
        telecharger_modele()
    ok = True
    ffmpeg = outils.trouver_ffmpeg()
    ffprobe = outils.trouver_ffmpeg("ffprobe")
    whisper = outils.trouver_whisper()
    modele = outils.trouver_modele()

    print("ffmpeg      :", ffmpeg or "ABSENT")
    print("ffprobe     :", ffprobe or "ABSENT")
    if not ffmpeg or not ffprobe:
        ok = False
        print("  -> Mac : brew install ffmpeg-full   |   Windows : winget install Gyan.FFmpeg")
    else:
        libass = outils.a_le_filtre(ffmpeg, "subtitles")
        print("sous-titres :", "oui (libass)" if libass else "NON, ce ffmpeg ne sait pas incruster de sous-titres")
        if not libass:
            print("  -> Mac : brew install ffmpeg-full (le ffmpeg standard de Homebrew n'a pas libass)")
            print("     Le montage marche quand même, les sous-titres sortent alors en fichier .srt à part.")
    print("whisper-cli :", whisper or "ABSENT")
    if not whisper:
        ok = False
        print("  -> Mac : brew install whisper-cpp   |   Windows : whisper-bin-x64.zip sur github.com/ggml-org/whisper.cpp/releases")
    print("modèle      :", modele or "ABSENT")
    if not modele:
        ok = False
        print("  -> python3 verifier.py --telecharger-modele")
    print()
    print("PRÊT" if ok else "INCOMPLET : installe ce qui manque, puis relance ce script.")
    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
