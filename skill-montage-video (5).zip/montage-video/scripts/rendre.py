"""Étape 3 : rend le montage validé, avec son normalisé, sous-titres et version verticale en option.

Chaque coupe tombe dans un blanc (entre deux îlots), jamais au milieu d'un mot, avec une petite marge
et un fondu audio de 10 ms pour éviter les clics. Toutes les durées sont mesurées par ffprobe.

Usage : python3 rendre.py DOSSIER [--sous-titres] [--vertical] [--marge-avant 0.08] [--marge-apres 0.15]
Sortie : montage.mp4, montage.srt, raccords.txt, et selon les options montage-sous-titres.mp4, montage-vertical.mp4
"""
import argparse
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import outils  # noqa: E402

STYLE_16_9 = "FontName=Arial,FontSize=18,Bold=1,PrimaryColour=&H00FFFFFF,OutlineColour=&H00000000,BorderStyle=1,Outline=2,Shadow=0,Alignment=2,MarginV=22"
STYLE_9_16 = "FontName=Arial,FontSize=12,Bold=1,PrimaryColour=&H00FFFFFF,OutlineColour=&H00000000,BorderStyle=1,Outline=2,Shadow=0,Alignment=2,MarginV=70"


def segments(ilots, garder, total, avant, apres):
    gardes = [il for il in ilots if il["id"] in set(garder)]
    bruts = [[max(0.0, il["debut"] - avant), min(total, il["fin"] + apres), il] for il in gardes]
    fusion = []
    for debut, fin, il in bruts:
        if fusion and debut <= fusion[-1][1] + 0.05:
            fusion[-1][1] = max(fusion[-1][1], fin)
            fusion[-1][2].append(il)
        else:
            fusion.append([debut, fin, [il]])
    return fusion


def decouper_texte(texte, maximum=42):
    mots, lignes, courant = texte.split(), [], ""
    for mot in mots:
        if courant and len(courant) + 1 + len(mot) > maximum:
            lignes.append(courant)
            courant = mot
        else:
            courant = (courant + " " + mot).strip()
    if courant:
        lignes.append(courant)
    return lignes


def horodatage_srt(t):
    h, reste = divmod(max(0.0, t), 3600)
    m, s = divmod(reste, 60)
    return f"{int(h):02d}:{int(m):02d}:{int(s):02d},{int(round((s - int(s)) * 1000)) % 1000:03d}"


def ecrire_srt(chemin, fusion):
    numero, position, lignes = 1, 0.0, []
    raccords = []
    for debut, fin, ilots in fusion:
        for il in ilots:
            texte = " ".join(il["texte"].replace("[BLANK_AUDIO]", "").split())
            if not texte:
                continue
            t0 = position + max(0.0, il["debut"] - debut)
            t1 = position + min(fin, il["fin"]) - debut
            morceaux = decouper_texte(texte)
            total_car = sum(len(x) for x in morceaux) or 1
            t = t0
            for morceau in morceaux:
                d = (t1 - t0) * len(morceau) / total_car
                lignes.append(f"{numero}\n{horodatage_srt(t)} --> {horodatage_srt(t + d)}\n{morceau}\n")
                numero, t = numero + 1, t + d
        position += fin - debut
        raccords.append(position)
    with open(chemin, "w", encoding="utf-8") as f:
        f.write("\n".join(lignes))
    return raccords[:-1]


def main():
    p = argparse.ArgumentParser()
    p.add_argument("dossier")
    p.add_argument("--sous-titres", action="store_true")
    p.add_argument("--vertical", action="store_true")
    p.add_argument("--marge-avant", type=float, default=0.08)
    p.add_argument("--marge-apres", type=float, default=0.15)
    a = p.parse_args()

    ffmpeg = outils.trouver_ffmpeg()
    if not ffmpeg:
        sys.exit("ffmpeg absent : lance verifier.py")
    with open(os.path.join(a.dossier, "ilots.json"), encoding="utf-8") as f:
        donnees = json.load(f)
    with open(os.path.join(a.dossier, "plan.json"), encoding="utf-8") as f:
        plan = json.load(f)

    video, total = donnees["video"], donnees["duree"]
    fusion = segments(donnees["ilots"], plan["garder"], total, a.marge_avant, a.marge_apres)
    if not fusion:
        sys.exit("Le plan ne garde aucun îlot.")

    graphe = []
    for k, (debut, fin, _) in enumerate(fusion):
        d = fin - debut
        graphe.append(f"[0:v]trim=start={debut:.3f}:end={fin:.3f},setpts=PTS-STARTPTS[v{k}]")
        graphe.append(f"[0:a]atrim=start={debut:.3f}:end={fin:.3f},asetpts=PTS-STARTPTS,"
                      f"afade=t=in:st=0:d=0.01,afade=t=out:st={max(0.0, d - 0.01):.3f}:d=0.01[a{k}]")
    entrees = "".join(f"[v{k}][a{k}]" for k in range(len(fusion)))
    graphe.append(f"{entrees}concat=n={len(fusion)}:v=1:a=1[vc][ac]")
    graphe.append("[ac]loudnorm=I=-14:TP=-1.5:LRA=11,aresample=48000[aout]")
    fichier_graphe = os.path.join(a.dossier, "graphe.txt")
    with open(fichier_graphe, "w", encoding="utf-8") as f:
        f.write(";\n".join(graphe))

    option_graphe = ["-/filter_complex", fichier_graphe] if outils.version_majeure(ffmpeg) >= 7 else ["-filter_complex_script", fichier_graphe]
    montage = os.path.join(a.dossier, "montage.mp4")
    encodeur = outils.encodeur_video(ffmpeg)
    outils.lancer([ffmpeg, "-y", "-hide_banner", "-loglevel", "error", "-i", video, *option_graphe,
                   "-map", "[vc]", "-map", "[aout]", *encodeur, "-pix_fmt", "yuv420p",
                   "-c:a", "aac", "-b:a", "192k", "-movflags", "+faststart", montage])

    raccords = ecrire_srt(os.path.join(a.dossier, "montage.srt"), fusion)
    with open(os.path.join(a.dossier, "raccords.txt"), "w", encoding="utf-8") as f:
        f.write("Raccords à écouter dans montage.mp4 :\n")
        for r in raccords:
            f.write(outils.secondes(r) + "\n")

    libass = outils.a_le_filtre(ffmpeg, "subtitles")
    produits = [montage]
    if a.sous_titres and not libass:
        print("Attention : ce ffmpeg n'a pas libass, les sous-titres restent dans montage.srt (Mac : brew install ffmpeg-full).")
    if a.sous_titres and libass:
        sortie = os.path.join(a.dossier, "montage-sous-titres.mp4")
        outils.lancer([ffmpeg, "-y", "-hide_banner", "-loglevel", "error", "-i", "montage.mp4",
                       "-vf", f"subtitles=montage.srt:force_style='{STYLE_16_9}'", *encodeur, "-pix_fmt", "yuv420p",
                       "-c:a", "copy", "-movflags", "+faststart", "montage-sous-titres.mp4"], cwd=a.dossier)
        produits.append(sortie)
    if a.vertical:
        filtre = "crop=trunc(ih*9/16/2)*2:ih,scale=1080:1920"
        if a.sous_titres and libass:
            filtre += f",subtitles=montage.srt:force_style='{STYLE_9_16}'"
        outils.lancer([ffmpeg, "-y", "-hide_banner", "-loglevel", "error", "-i", "montage.mp4",
                       "-vf", filtre, *encodeur, "-pix_fmt", "yuv420p",
                       "-c:a", "copy", "-movflags", "+faststart", "montage-vertical.mp4"], cwd=a.dossier)
        produits.append(os.path.join(a.dossier, "montage-vertical.mp4"))

    duree_montage = outils.duree(montage)
    print(f"Source : {total:.1f} s | montage : {duree_montage:.1f} s | retiré : {total - duree_montage:.1f} s "
          f"({100 * (total - duree_montage) / total:.0f} %) | raccords : {len(raccords)}")
    for chemin in produits:
        print("Fichier :", chemin)
    print("Raccords à écouter :", os.path.join(a.dossier, "raccords.txt"))


if __name__ == "__main__":
    main()
