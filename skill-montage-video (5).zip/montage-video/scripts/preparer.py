"""Étape 1 du montage : repère les blancs, découpe la parole en îlots et range la transcription dedans.

Les îlots sont les passages de parole entre deux blancs : toutes les coupes tomberont dans un blanc,
jamais au milieu d'un mot. La vidéo est transcrite d'un seul bloc (les extraits trop courts font
halluciner Whisper), puis chaque morceau de texte est rangé dans l'îlot où tombe son milieu.

Usage : python3 preparer.py VIDEO [--dossier DOSSIER] [--seuil -35] [--silence 0.35] [--langue fr]
Sortie : DOSSIER/ilots.json et DOSSIER/ilots.txt (la version courte à lire)
"""
import argparse
import json
import os
import re
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import outils  # noqa: E402


def silences(ffmpeg, audio, seuil, minimum):
    sortie = outils.lancer([ffmpeg, "-hide_banner", "-nostats", "-i", audio,
                            "-af", f"silencedetect=noise={seuil}dB:d={minimum}", "-f", "null", "-"]).stderr
    debuts = [float(x) for x in re.findall(r"silence_start: (-?[\d.]+)", sortie)]
    fins = [float(x) for x in re.findall(r"silence_end: ([\d.]+)", sortie)]
    return list(zip(debuts, fins + [None] * (len(debuts) - len(fins))))


def ilots_depuis_silences(blancs, total):
    ilots, curseur = [], 0.0
    for debut, fin in blancs:
        debut = max(0.0, debut)
        if debut - curseur > 0.05:
            ilots.append([curseur, debut])
        curseur = fin if fin is not None else total
    if total - curseur > 0.05:
        ilots.append([curseur, total])
    return ilots


def main():
    p = argparse.ArgumentParser()
    p.add_argument("video")
    p.add_argument("--dossier")
    p.add_argument("--seuil", type=float, default=-35, help="niveau en dB sous lequel on considère un blanc")
    p.add_argument("--silence", type=float, default=0.35, help="durée minimale d'un blanc, en secondes")
    p.add_argument("--langue", default="fr")
    a = p.parse_args()

    ffmpeg, whisper, modele = outils.trouver_ffmpeg(), outils.trouver_whisper(), outils.trouver_modele()
    if not (ffmpeg and whisper and modele):
        sys.exit("Outils manquants : lance d'abord verifier.py")

    dossier = outils.dossier_de_travail(a.video, a.dossier)
    total = outils.duree(a.video)
    audio = os.path.join(dossier, "audio.wav")
    outils.lancer([ffmpeg, "-y", "-hide_banner", "-loglevel", "error", "-i", a.video,
                   "-vn", "-ac", "1", "-ar", "16000", audio])

    blancs = silences(ffmpeg, audio, a.seuil, a.silence)
    bruts = ilots_depuis_silences(blancs, total)

    # une seule transcription de toute la bande son, avec horodatage de chaque morceau
    prefixe = os.path.join(dossier, "transcription")
    # -mc 0 : chaque morceau est transcrit sans le texte précédent, ce qui évite que Whisper parte en boucle
    # -ml 1 -sow : un horodatage par mot, pour ranger chaque mot dans le bon îlot même quand Whisper enchaîne deux phrases
    outils.lancer([whisper, "-m", modele, "-l", a.langue, "-f", audio, "-oj", "-of", prefixe, "-np", "-sns", "-mc", "0",
                   "-ml", "1", "-sow"])
    with open(prefixe + ".json", encoding="utf-8", errors="replace") as f:
        morceaux = json.load(f).get("transcription", [])

    ilots = [{"id": i, "debut": round(d, 3), "fin": round(f, 3), "duree": round(f - d, 3), "texte": ""}
             for i, (d, f) in enumerate(bruts, 1)]
    for morceau in morceaux:
        texte = " ".join(morceau.get("text", "").split())
        if not texte:
            continue
        milieu = (morceau["offsets"]["from"] + morceau["offsets"]["to"]) / 2000
        # l'îlot qui contient le milieu du mot ; si le mot tombe dans un blanc, l'îlot qui suit,
        # car Whisper place souvent le premier mot après une pause un peu trop tôt, dans le silence
        # sauf un mot qui termine une phrase (« blancs. ») : lui appartient à l'îlot d'avant
        dedans = [il for il in ilots if il["debut"] <= milieu <= il["fin"]]
        avant = [il for il in ilots if il["fin"] < milieu]
        apres = [il for il in ilots if il["debut"] > milieu]
        if dedans:
            cible = dedans[0]
        elif avant and (texte.endswith((".", "!", "?", "…")) or not apres):
            cible = avant[-1]
        else:
            cible = apres[0] if apres else ilots[-1]
        cible["texte"] = (cible["texte"] + " " + texte).strip()
    for il in ilots:
        # la ponctuation arrive parfois collée en mot séparé : « bonjour , » devient « bonjour, »
        il["texte"] = re.sub(r"\s+([,.!?;:…])", r"\1", il["texte"])

    with open(os.path.join(dossier, "ilots.json"), "w", encoding="utf-8") as f:
        json.dump({"video": os.path.abspath(a.video), "duree": round(total, 3), "ilots": ilots}, f,
                  ensure_ascii=False, indent=1)
    with open(os.path.join(dossier, "ilots.txt"), "w", encoding="utf-8") as f:
        for il in ilots:
            f.write(f"#{il['id']:03d} [{il['debut']:.2f} - {il['fin']:.2f}] {il['duree']:.1f} s | {il['texte']}\n")

    parole = sum(il["duree"] for il in ilots)
    print(f"Vidéo : {total:.1f} s | parole : {parole:.1f} s | blancs : {total - parole:.1f} s | îlots : {len(ilots)}")
    print("Transcription îlot par îlot :", os.path.join(dossier, "ilots.txt"))


if __name__ == "__main__":
    main()
